const fs = require('fs');
const path = require('path');
const MongoClient = require('mongodb').MongoClient;
const include = ["addins", "libraries", "resources", "reports", "rules", "views"];
const providers = { trdx: 'Telerik' }
const dirName = path.join(__dirname, process.argv[2]);
const orgKey = (typeof (process.argv[3]) == 'string') ? process.argv[3] : 'demo';
const powerjs = (typeof (process.argv[4]) == 'string') ? process.argv[4] : 'power.js';

(async function run() {
    let package = {
        "objectType" : "package",
        "packageKey" : dirName.split('\\').pop().toLowerCase(),
        "vendorKey" : "powerhub",
        "packageItems" : {
            "addins" : {},
            "libraries" : {},
            "resources" : {},
            "reports" : {},
            "rules" : {},
            "views" : {}
        },
        "config": {}
    }

    let folders = fs.readdirSync(dirName).filter(item => fs.statSync(path.join(dirName, item)).isDirectory());

    folders.forEach(folder => {
        if (include.indexOf(folder) > -1) {
            let files = fs.readdirSync(path.join(dirName, folder)).filter(item => fs.statSync(path.join(dirName, folder, item)).isFile());
            if (folder == 'addins') {
                files.forEach(file => {
                    let fname = file.split('.')[0];
                    let content = fs.readFileSync(path.join(dirName, folder, file), 'utf8');
                    package.packageItems.addins[fname.toLowerCase()] = {
                        "content" : content
                    };
                });
            }
            else if (folder == 'libraries') {
                files.forEach(file => {
                    let fname = file.split('.')[0];
                    let content = fs.readFileSync(path.join(dirName, folder, file), 'utf8');
                    package.packageItems.libraries[fname.toLowerCase()] = {
                        "content" : content
                    };
                });
            }
            else if (folder == 'resources') {
                files.forEach(file => {
                    let fname = file.split('.')[0];
                    let content = `export default ` + fs.readFileSync(path.join(dirName, folder, file), 'utf8');
                    package.packageItems.resources[fname.toLowerCase()] = {
                        "content" : content
                    };
                });
            }
            else if (folder == 'reports') {
                files.forEach(file => {
                    let parts = file.split('.');
                    let fname = parts[0];
                    let ext = parts[1];
                    let content = fs.readFileSync(path.join(dirName, folder, file), 'utf8');
                    package.packageItems.reports[fname.toLowerCase()] = {
                        "provider" : providers[ext],
                        "content" : content
                    };
                });
            }
            else if (folder == 'rules') {
                files.forEach(file => {
                    let fname = file.split('.')[0];
                    let content = fs.readFileSync(path.join(dirName, folder, file), 'utf8');
                    package.packageItems.rules[fname.toLowerCase()] = {
                        "content" : content
                    };
                });
            }
            else if (folder == 'views') {
                files.forEach(file => {
                    let fname = file.split('.')[0];
                    let viewMarkup = fs.readFileSync(path.join(dirName, folder, file), 'utf8');
                    let content = getViewComponentCode(fname, viewMarkup);
                    package.packageItems.views[fname.toLowerCase()] = {
                        "content" : content
                    };
                });
            }
        }
    });

    if (fs.existsSync(path.join(dirName, "config.json"))) {
        let config = fs.readFileSync(path.join(dirName, "config.json"), 'utf8');
        package.config = JSON.parse(config);
    }

    // Deploy package to the org
    const uri = "mongodb://lithium4:fsytmpmhW25j5R8jjwuARVxElxCfdBFMvLNElp4HR97qs6C9nejsXd6askY4Y1Nt2tvznwkZpQutZKvGpLtQuA%3D%3D@lithium4.documents.azure.com:10255/lithium4db?ssl=true&replicaSet=globaldb";
    const client = new MongoClient(uri, { useNewUrlParser: true });

    try {
        let conn = await client.connect();
        let db = conn.db();
    
        await db.collection(orgKey).deleteOne({ objectType: "package", packageKey: package.packageKey });
        await db.collection(orgKey).insertOne(package);
        client.close();
        console.log(`The package "${process.argv[2]}" has been published to the ${orgKey} organization.`);
    }
    catch (e) {
        client.close();
        console.log(`The package "${process.argv[2]}" could not be published to the ${orgKey} organization.`);
        console.log(package);
        console.log(e);
    }

    return;
})();

function getViewComponentCode(className, viewMarkup) {
    viewMarkup = parseViewControls(viewMarkup.replace("'", "\\'")).replace(/\r?\n|\r/g, ' '); // escape single quotes
    let code = `
        import View from '/lib/js/${powerjs}';
        export default class ${className} extends View {
            constructor(args) {
                args.viewmarkup = '${viewMarkup}';
                super(args);
            }
        }
    `;
    return code;
}

// METHOD: parseViewControls
function parseViewControls(viewMarkup) {
    let controls = viewMarkup.match(/<(\/p|p):([a-zA-Z -=\[\]]+)>/g);
    let controlMarkup = "";
  
    if (controls == null) return viewMarkup;
  
    for (let i = 0; i < controls.length; i++) {
        if (controls[i].startsWith("<p:button")) {
            controlMarkup = getButtonMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:checkbox")) {
            controlMarkup = getCheckboxMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:datepicker")) {
            controlMarkup = getDatepickerMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:file")) {
            controlMarkup = getFileMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:menu")) {
            controlMarkup = getMenuMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:radiogroup")) {
            controlMarkup = getRadioGroupMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:repeater")) {
            controlMarkup = getRepeaterMarkup(controls[i]);
        }
        else if (controls[i].startsWith("</p:repeater>")) {
            controlMarkup = "</template></ul>";
        }
        else if (controls[i].startsWith("<p:select")) {
            controlMarkup = getSelectMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:tags")) {
            controlMarkup = getTagsMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:chipslist")) {
            controlMarkup = getChipslistMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:calendar")) {
            controlMarkup = getCalendarMarkcup(controls[i]);
        }
        else if (controls[i].startsWith("<p:textarea")) {
            controlMarkup = getTextareaMarkup(controls[i]);
        }
        else if (controls[i].startsWith("<p:textbox")) {
            controlMarkup = getTextboxMarkup(controls[i]);
        }
        else {
            continue;
        }
        viewMarkup = viewMarkup.replace(controls[i], controlMarkup);
    }
  
    return viewMarkup;
}
  
function getButtonMarkup(control) {
    let controlMarkup = '<a data-view-control="button" @attributes><i class="material-icons"></i><span></span></a>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="btn ') : attributes + ' class="btn"';
    return controlMarkup.replace("@attributes", attributes);
}
  
function getCheckboxMarkup(control) {
    let controlMarkup = '<label data-view-control="checkbox" @attributes><input type="checkbox" class="filled-in"/><span></span></label>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    return controlMarkup.replace("@attributes", attributes);
}
  
function getDatepickerMarkup(control) {
    let controlMarkup = '<div data-view-control="datepicker" @attributes><i class="material-icons"></i><input type="text" class="datepicker"><label></label><span class="helper-text"></span></div>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="input-field ') : attributes + ' class="input-field"';
    return controlMarkup.replace("@attributes", attributes);
}
  
function getFileMarkup(control) {
    let controlMarkup = '<div data-view-control="file" @attributes><div class="btn"><label style="color: #ffffff"></label><input type="file"></div><div class="file-path-wrapper"><input class="file-path" type="text"></div><span class="helper-text"></span></div>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="file-field input-field ') : attributes + ' class="file-field input-field"';
    return controlMarkup.replace("@attributes", attributes);
}
  
function getMenuMarkup(control) {
    let controlMarkup = '<ul data-view-control="menu" @attributes></a></ul>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="dropdown-content ') : attributes + ' class="dropdown-content"';
    return controlMarkup.replace("@attributes", attributes);
}

function getRadioGroupMarkup(control) {
    let controlMarkup = '<div data-view-control="radiogroup" @attributes><span></span>@radiogroup</div>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="radiogroup ') : attributes + ' class="radiogroup"';
    return controlMarkup.replace("@attributes", attributes);
}

function getRepeaterMarkup(control) {
    let controlMarkup = '<ul data-view-control="repeater" @attributes><template>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf(">"));
    return controlMarkup.replace("@attributes", attributes);
}

function getSelectMarkup(control) {
    let controlMarkup = '<div data-view-control="select" @attributes><i class="material-icons"></i><select><select><label></label><span class="helper-text"></span></div>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="input-field ') : attributes + ' class="input-field"';
    return controlMarkup.replace("@attributes", attributes);
}

function getTagsMarkup(control) {
    let controlMarkup = '<div data-view-control="tags" @attributes><input/><span style="position: absolute; top: 50px;" class="helper-text"></span></div>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="chips ') : attributes + ' class="chips"';
    return controlMarkup.replace("@attributes", attributes);
}

function getChipslistMarkup(control) {
    let controlMarkup = '<div data-view-control="chipslist" @attributes></div>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="inline-block ') : attributes + ' class="inline-block"';
    return controlMarkup.replace("@attributes", attributes);
}

function getCalendarMarkcup(control) {
    let controlMarkup = '<div data-view-control="calendar" @attributes><div class="month"></div><div class="date"></div><div class="year"></div></div>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="calendar ') : attributes + ' class="calendar"';
    return controlMarkup.replace("@attributes", attributes);
}

function getTextareaMarkup(control) {
    let controlMarkup = '<div data-view-control="textarea" @attributes><i class="material-icons"></i><textarea class="materialize-textarea"></textarea><label></label><span class="helper-text"></span></div>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="input-field ') : attributes + ' class="input-field"';
    return controlMarkup.replace("@attributes", attributes);
}

function getTextboxMarkup(control) {
    let controlMarkup = '<div data-view-control="textbox" @attributes><i class="material-icons"></i><input type="text"><label></label><span class="helper-text"></span></div>';
    let attributes = control.substring(control.indexOf(" ") + 1, control.lastIndexOf("/"));
    attributes = attributes.indexOf('class="') != -1 ? attributes.replace(/class="/, 'class="input-field ') : attributes + ' class="input-field"';
    return controlMarkup.replace("@attributes", attributes);
}

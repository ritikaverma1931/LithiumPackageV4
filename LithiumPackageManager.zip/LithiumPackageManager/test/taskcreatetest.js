const assert = require('chai').assert;
const expect = require('chai').expect;
const axios = require('axios');
const Mongo = require('mongodb').MongoClient;

// const uri = "mongodb://lithium4.documents.azure.com:10255/?ssl=true&replicaSet=globaldb";
// Mongo.connect(uri, {user: 'lithium4', pass: 'WwXa0lgmoD6L57dVe19CaRwkG49PmCGG74W8BB7XwGsCK72CMVskxz91kleuODZMbZ7ICE3dozJEpOvlKw1QRQ=='}, function (err, db) {
   
//      if(err) throw err;
//      console.log("connected!!!", db)

//      //Write databse Insert/Update/Query code here..
                
// });
describe('Create task', async function() {

    it('Test validates if task gets created', function() {
         axios.post('https://powerhubsolutions.com/demo/package/ritikapackage/rules/taskcreate', {
            objectType: 'task',
            name: 'Task by Anju',
            description: 'Test Task Create'
        })
        .then(async function (response) {
            //console.log(response);
            var resp = await connectMongoDb();
            //let result = response.data.data;            
           // expect(response.data.data).to.equals('Task is created, Task by Anju'+resp);
        })
       .catch(function (error) {
            console.log(error);
        })
    });

  });


function connectMongoDb(){
    console.log("connecting!!!!")
    const uri = "mongodb://lithium4.documents.azure.com:10255/?ssl=true";
     Mongo.connect(uri, {
            useNewUrlParser: true,
            user: 'lithium4', 
            pass: 'WwXa0lgmoD6L57dVe19CaRwkG49PmCGG74W8BB7XwGsCK72CMVskxz91kleuODZMbZ7ICE3dozJEpOvlKw1QRQ=='
        },
        (err,client) => {
            //console.log("connected to db", client);
            if (!err) {
                const dbo = client.db("lithium4db");
                //console.log("here is dbo data", dbo)
                dbo.collection('demo',(err,response)=> {
                    //console.log("get the olletidslkflds", response)
                    response.find()
                    .toArray((err, result)=> {
                        if(err) {
                            console.log("error while fetching", err)
                        }
                        console.log("her is the result:", result)
                    })
                    client.close();
                });
                // dbo.collection("demo")
                // .find({ "_id": "5cb546be7dfa951b68f189d7"})
                // .toArray(function(err, result) {
                //     if (err) throw err;
                //     console.log(result);
                //     db.close();
                // });
            }
        })
  }

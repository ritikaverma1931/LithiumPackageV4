
// let sql = require("mssql");
// const MongoClient = require('mongodb').MongoClient;

// async function run() {
   
//     const uri = "mongodb://lithium4:fsytmpmhW25j5R8jjwuARVxElxCfdBFMvLNElp4HR97qs6C9nejsXd6askY4Y1Nt2tvznwkZpQutZKvGpLtQuA%3D%3D@lithium4.documents.azure.com:10255/lithium4db?ssl=true&replicaSet=globaldb";
//     //const uri = "mongodb+srv://mrazi:Maryam_razi84@maryamdbserver-wkwes.azure.mongodb.net/test?retryWrites=true&w=majority";
//     const client = new MongoClient(uri, { useNewUrlParser: true });
               
//     try {
//         //const collection = client.db("PowerHubTest").collection("IPP");
         
//         let conn = await client.connect();
//         let db = conn.db('lithiumcosmosdb');

//         db.getCollection('demo').find({"objectType":"task"});        
//         console.log('Connecting to mongo db');
//         await client.close();
//     }
//     catch (e) {
//         console.log(`its failed`);
//         console.log(e);
//     }
// }

// run();


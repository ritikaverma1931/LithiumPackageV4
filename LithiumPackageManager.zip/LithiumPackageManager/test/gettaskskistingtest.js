/*const assert = require('chai').assert;
const expect = require('chai').expect;
const axios = require('axios');
var Mongo = require('mongodb').MongoClient;


describe('Create task', function() {

    it('Test validates if task gets created', function() {
         axios.post('https://powerhubsolutions.com/demo/package/ritikapackage/rules/gettaskslisting', {
            objectType: 'task',
            name: 'Task by Anju',
            description: 'Test Task Create'
        })
        .then(function (response) {
            //const url = `mongodb://${MONGO_USERNAME}:${MONGO_PASSWORD}@${MONGO_HOSTNAME}:${MONGO_PORT}/${MONGO_DB}?authSource=admin`;
            
            //console.log(response);
            let result = response.data.data;            
            expect(response.data.data).to.equals('Task is created, Task by Anju');
        })
       .catch(function (error) {
            console.log(error);
        })
    });

  });

  function connectMongoDb(){
    const uri = "mongodb://lithium4:WwXa0lgmoD6L57dVe19CaRwkG49PmCGG74W8BB7XwGsCK72CMVskxz91kleuODZMbZ7ICE3dozJEpOvlKw1QRQ==@lithium4.documents.azure.com:10255/lithium4db?ssl=true&replicaSet=globaldb";
    //const uri = "mongodb+srv://mrazi:Maryam_razi84@maryamdbserver-wkwes.azure.mongodb.net/test?retryWrites=true&w=majority";
    
               
    try {
        Mongo.connect(uri, (err,client) => {
            if (err) {
                console.error(err)
                return
              }
        })
    }
    catch (e) {
        console.log(`its failed`);
        console.log(e);
    }
  }
*/
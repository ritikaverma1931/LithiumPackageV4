//This is the tasks controller
//debugger;
import TaskCreateView from './package/ritikapackage/views/taskcreate';

let view = new TaskCreateView({ viewport : 'app'  });
//debugger;
view.viewModel = {    
    save:{
        onclick: onSaveClick,
        label:'Save'
    },
    name:{
        label:'Name',        
        value:''
    },
    description:{
        label:'Description',
        value:''
    },
    status:{
        label:'Statussss',
        value:''
    },
    duedate:{
        label:'Duedate111',
        value:''
    },
    nameheader:{
        label:'Name Header'
    },
    msg: {
        visible: false
    }
}        
view.refresh();

function onSaveClick()
{
    axios.post('./package/ritikapackage/rules/taskcreate', {
        objectType: 'task', 
        name: view.viewModel.name.value,
        description: view.viewModel.description.value
    })
   .then(function (response) {               
        console.log(response.data.data);
        debugger;
        view.viewModel.msg.content = response.data.data;
        view.viewModel.msg.visible = true;
        view.refresh();
   })
   .catch(function (error) {
        console.log(error);
        view.viewModel.msg.content = "Task create is failed";
        view.viewModel.msg.visible = true;
        view.refresh();
   });
}
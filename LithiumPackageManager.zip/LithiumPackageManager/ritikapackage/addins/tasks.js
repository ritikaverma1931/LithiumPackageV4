//This is the tasks controller
//debugger;
import TasksListingView from './package/ritikapackage/views/taskslisting';

let view = new TasksListingView({ viewport : 'app'  });
let tasks = [];

axios.get('./package/ritikapackage/rules/gettaskslisting')
   .then(function (response) {
       
        tasks = response.data.data;
        //debugger;
        view.viewModel = {
            tasks: {
                value: []
            }
        }

        for (var task of tasks) {
            view.viewModel.tasks.value.push({
                name: {
                    bindto: { model: tasks, property: 'name'}
                },
                description: {
                    bindto: { model: tasks, property: 'description'}
                },
                duedate: {
                    bindto: { model: tasks, property: 'duedate'}
                },
                status: {
                    bindto: { model: tasks, property: 'status'}
                }
            })
        }

        view.refresh();

   })
   .catch(function (error) {
       console.log(error);
   });



   


   //https://powerhubsolutions.com/demo/run?packageKey=maryampackage&addinKey=tasks

async function Main() {

    let task = await ctx.db.insertOne(ctx.data);
    let createdTask = await ctx.db.findOne({ objectType: 'task', name: ctx.data.name, description: ctx.data.description });
    debugger;

    if (task) {

        //console.log("Task----");
        //console.log(task.ops[0]);
       // return `Task is created, ${createdTask._id}`;
        return task.ops[0]._id;
    }
    else {
        return "Task Create is Failed";
    }
 }
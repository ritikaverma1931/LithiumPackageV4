
async function Main() {

   let tasks = await ctx.db.find({ objectType: 'task' }).toArray();
   /*let tasks = await ctx.db.aggregate([{
        $match: {
            objectType: 'task'
        }
    }, {
        $group: {
            _id: "$status",
            totalcount: {
                $sum: 1
            }
        }
    }]).toArray();
   */

   if (tasks) {
       return tasks;
   }
   else {
       return "Tasks Failed";
   }
}